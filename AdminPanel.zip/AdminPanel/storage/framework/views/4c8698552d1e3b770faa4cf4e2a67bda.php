<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Developers List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2 class="mb-4">Developers List</h2>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Title</th>
                <th>Description</th>
                <th>Photo</th>
                <th>Icon 1</th>
                <th>Icon 2</th>
                <th>Icon 3</th>
                <th>Copyright</th>
                <th>Sort Order</th>
                
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $developers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $developer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($developer->id); ?></td>
                <td><?php echo e($developer->name); ?></td>
                <td><?php echo e($developer->title); ?></td>
                <td><?php echo e($developer->description); ?></td>
                <td>
                    <?php if($developer->photo): ?>
                        <img src="<?php echo e(asset('storage/' . $developer->photo)); ?>" width="50">
                    <?php else: ?>
                        No Photo
                    <?php endif; ?>
                </td>
                <td><?php echo e($developer->icon_1_text); ?></td>
                <td><?php echo e($developer->icon_2_text); ?></td>
                <td><?php echo e($developer->icon_3_text); ?></td>
                <td><?php echo e($developer->copyright_text); ?></td>
                <td><?php echo e($developer->sort_order); ?></td>
            
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</body>
</html>
<?php /**PATH D:\RS Lexury code old\laravel\AdminPanel\resources\views/developerView.blade.php ENDPATH**/ ?>