<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Why </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
  
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>




    <h3 class="mt-4">Existing Why Sections</h3>
    <table class="table table-bordered mt-3">
        <thead>
            <tr>
                <th>ID</th>
                <th>Developer ID</th>
                <th>Why Section 1</th>
                <th>Image 1</th>
                <th>Why Section 2</th>
                <th>Image 2</th>
                <th>Why Section 3</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $whySections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $why): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($why->id); ?></td>
                <td><?php echo e($why->developer_id); ?></td>
                <td><?php echo e($why->why_section1); ?></td>
                <td>
                    <?php if($why->why_1_image): ?>
                        <img src="<?php echo e(asset('storage/' . $why->why_1_image)); ?>" width="50">
                    <?php else: ?>
                        No Image
                    <?php endif; ?>
                </td>
                <td><?php echo e($why->why_section2); ?></td>
                <td>
                    <?php if($why->why_2_image): ?>
                        <img src="<?php echo e(asset('storage/' . $why->why_2_image)); ?>" width="50">
                    <?php else: ?>
                        No Image
                    <?php endif; ?>
                </td>
                <td><?php echo e($why->why_section3); ?></td>
                <td>
                    <form action="<?php echo e(url('why/' . $why->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</body>
</html>
<?php /**PATH D:\RS Lexury code old\laravel\AdminPanel\resources\views/whyView.blade.php ENDPATH**/ ?>