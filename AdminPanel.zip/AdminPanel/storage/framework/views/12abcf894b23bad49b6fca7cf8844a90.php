<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Content List</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Pages List</h2>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Meta</th>
                    <th>H1</th>
                    <th>H2</th>
                    <th>H3</th>
                    <th>H4</th>
                    <th>H5</th>
                    <th>H6</th>
                    <th>Para 1</th>
                    <th>Para 2</th>
                    <th>Created At</th>
                    <th>Updated At</th>
                    <th>Updated By</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($page->id); ?></td>
                        <td><?php echo e($page->title); ?></td>
                        <td><?php echo e($page->meta); ?></td>
                        <td><?php echo e($page->h1); ?></td>
                        <td><?php echo e($page->h2); ?></td>
                        <td><?php echo e($page->h3); ?></td>
                        <td><?php echo e($page->h4); ?></td>
                        <td><?php echo e($page->h5); ?></td>
                        <td><?php echo e($page->h6); ?></td>
                        <td><?php echo e($page->para1); ?></td>
                        <td><?php echo e($page->para2); ?></td>
                        <td><?php echo e($page->created_at); ?></td>
                        <td><?php echo e($page->updated_at); ?></td>
                        <td><?php echo e($page->updated_by); ?></td>
                        <td>
                            <?php if($page->status): ?>
                                <span class="badge bg-success">Active</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <form action="<?php echo e(route('content.destroy', $page->id)); ?>" method="POST" class="d-inline delete-form">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm delete-btn">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            document.querySelectorAll('.delete-btn').forEach(button => {
                button.addEventListener('click', function(event) {
                    event.preventDefault();
                    let form = this.closest("form");

                    Swal.fire({
                        title: "Are you sure?",
                        text: "You won't be able to revert this!",
                        icon: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#d33",
                        cancelButtonColor: "#3085d6",
                        confirmButtonText: "Yes, delete it!"
                    }).then((result) => {
                        if (result.isConfirmed) {
                            form.submit();
                        }
                    });
                });
            });
        });
    </script>

</body>
</html>
<?php /**PATH D:\RS Lexury code old\laravel\AdminPanel\resources\views/contentView.blade.php ENDPATH**/ ?>